﻿using APiRest.Context;
using Microsoft.EntityFrameworkCore;

namespace APiRest

{
    public class Startup
    {
        public IConfiguration Configuration { get; }



        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
        }



        public void ConfigureServices(IServiceCollection services)
        {

            services.AddCors(options =>
            {
                options.AddPolicy("AllowSpecificOrigin",
                    builder =>
                    {
                        builder
                            .WithOrigins("http://localhost:5173/") // Reemplaza con la URL de tu aplicación cliente
                            .AllowAnyHeader()
                            .AllowAnyMethod()
                            .WithExposedHeaders("Access-Control-Allow-Origin");
                    });
            });
            services.AddControllers();
            services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer(Configuration.GetConnectionString("Conexion")));
            // ...
        }




        public void Configure(IApplicationBuilder app, IHostApplicationLifetime lifetime)
        {

        }
    }
}
