﻿using APiRest.Context;
using APiRest.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace APiRest.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : Controller
    {
        private readonly AppDbContext _context;
        public ProductosController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult Get()
        {
            try
            {
                List<Producto> listProductos = new List<Producto>();

                SqlConnection conexion = (SqlConnection)_context.Database.GetDbConnection();
                SqlCommand comando = conexion.CreateCommand();
                conexion.Open();
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.CommandText = "GetAllProductos";
                SqlDataReader read = comando.ExecuteReader();
                while (read.Read())
                {
                    Producto product = new Producto();

                    product.Id = (int)read["Id"];
                    product.titulo = (string)read["Titulo"];
                    product.descripcion = (string)read["Descripcion"];
                    product.discountPercentage = (decimal)read["DiscountPercentage"];
                    product.rating = (decimal)read["Rating"];
                    product.precio = (decimal)read["Precio"];
                    product.stock= (int)read["Stock"];
                    product.categoria = (string)read["Categoria"];
                    product.imagen = (string)read["Imagen"];
                    product.thumbnail = (string)read["Thumbnail"];
                    product.estatus = (string)read["Estatus"];


                    listProductos.Add(product);
                }
                conexion.Close();
                return Json(listProductos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("search/{producto}")]
        public ActionResult Get(string producto)
        {
            try
            {
                List<Producto> listProductos = new List<Producto>();

                SqlConnection conexion = (SqlConnection)_context.Database.GetDbConnection();
                SqlCommand comando = conexion.CreateCommand();
                conexion.Open();
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.CommandText = "SearchProductosByName";
                comando.Parameters.Add("@ProductName", System.Data.SqlDbType.VarChar).Value = producto;
                SqlDataReader read = comando.ExecuteReader();
                while (read.Read())
                {
                    Producto product = new Producto();

                    product.Id = (int)read["Id"];
                    product.titulo = (string)read["Titulo"];
                    product.descripcion = (string)read["Descripcion"];
                    product.discountPercentage = (decimal)read["DiscountPercentage"];
                    product.rating = (decimal)read["Rating"];
                    product.precio = (decimal)read["Precio"];
                    product.stock = (int)read["Stock"];
                    product.categoria = (string)read["Categoria"];
                    product.imagen = (string)read["Imagen"];
                    product.thumbnail = (string)read["Thumbnail"];
                    product.estatus = (string)read["Estatus"];


                    listProductos.Add(product);
                }
                conexion.Close();
                return Json(listProductos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}")]
        public ActionResult GetByID(int id)
        {
            try
            {
                List<Producto> listProductos = new List<Producto>();

                SqlConnection conexion = (SqlConnection)_context.Database.GetDbConnection();
                SqlCommand comando = conexion.CreateCommand();
                conexion.Open();
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.CommandText = "SearchProductosById";
                comando.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = id;
                SqlDataReader read = comando.ExecuteReader();
                while (read.Read())
                {
                    Producto product = new Producto();

                    product.Id = (int)read["Id"];
                    product.titulo = (string)read["Titulo"];
                    product.descripcion = (string)read["Descripcion"];
                    product.discountPercentage = (decimal)read["DiscountPercentage"];
                    product.rating = (decimal)read["Rating"];
                    product.precio = (decimal)read["Precio"];
                    product.stock = (int)read["Stock"];
                    product.categoria = (string)read["Categoria"];
                    product.imagen = (string)read["Imagen"];
                    product.thumbnail = (string)read["Thumbnail"];
                    product.estatus = (string)read["Estatus"];


                    listProductos.Add(product);
                }
                conexion.Close();
                return Json(listProductos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



    }
}
