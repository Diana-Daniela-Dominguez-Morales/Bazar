﻿using APiRest.Models;
using Microsoft.EntityFrameworkCore;

namespace APiRest.Context
{
    public class AppDbContext : DbContext
    {
        private const string connectionString = "conexion";

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Producto> Alumnos { get; set; }
    }
}
