﻿using System.ComponentModel.DataAnnotations;

namespace APiRest.Models
{
    public class Producto
    {
        [Key]
        public int Id { get; set; }
        public string titulo { get; set; }
        public string descripcion {  get; set; }

        public decimal discountPercentage { get; set; }
        public decimal rating {  get; set; }
        
        public decimal precio { get; set; }
        public int stock {  get; set; }
        public string categoria { get; set; }
        public string imagen { get; set; }
        public string thumbnail { get; set; }
        public string estatus {  get; set; }

    }
}
